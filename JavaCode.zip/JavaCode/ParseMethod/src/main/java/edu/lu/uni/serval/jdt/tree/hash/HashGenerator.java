package edu.lu.uni.serval.jdt.tree.hash;

import edu.lu.uni.serval.jdt.tree.ITree;

public interface HashGenerator {

    public void hash(ITree t);

}
