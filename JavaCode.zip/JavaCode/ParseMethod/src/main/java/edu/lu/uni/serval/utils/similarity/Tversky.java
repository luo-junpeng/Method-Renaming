package edu.lu.uni.serval.utils.similarity;

import java.util.List;

/**
 * https://en.wikipedia.org/wiki/Tversky_index
 * @author kui.liu
 *
 */
public class Tversky implements Similarity {

	@Override
	public Double similarity(String str1, String str2) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <T> Double similarity(List<T> l1, List<T> l2) {
		// TODO Auto-generated method stub
		return null;
	}

}
